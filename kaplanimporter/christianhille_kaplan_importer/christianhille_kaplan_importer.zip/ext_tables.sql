#
# Table structure for table 'tx_kaplanimporter_domain_model_importdefinition'
#
CREATE TABLE tx_kaplanimporter_domain_model_importdefinition (
  
	uid int(11) NOT NULL auto_increment,
	pid int(11) DEFAULT '0' NOT NULL,

	name varchar(30) DEFAULT '' NOT NULL,
	url varchar(512) DEFAULT '' NOT NULL,
	categories int(11) DEFAULT '0' NOT NULL,
	target_folder int(11) DEFAULT '0' NOT NULL,
	rooms_and_places_as_categories smallint(5) unsigned DEFAULT '0' NOT NULL,
	category_as_category smallint(5) unsigned DEFAULT '0' NOT NULL,
	create_missing_categories smallint(5) unsigned DEFAULT '0' NOT NULL,
	days int(11) unsigned DEFAULT '21' NOT NULL,
	arbeitsgruppe varchar(100) DEFAULT '' NOT NULL,
	code varchar(30) DEFAULT '' NOT NULL,

	tstamp int(11) unsigned DEFAULT '0' NOT NULL,
	crdate int(11) unsigned DEFAULT '0' NOT NULL,
	cruser_id int(11) unsigned DEFAULT '0' NOT NULL,
	deleted smallint(5) unsigned DEFAULT '0' NOT NULL,
	hidden smallint(5) unsigned DEFAULT '0' NOT NULL,
	starttime int(11) unsigned DEFAULT '0' NOT NULL,
	endtime int(11) unsigned DEFAULT '0' NOT NULL,

	t3ver_oid int(11) DEFAULT '0' NOT NULL,
	t3ver_id int(11) DEFAULT '0' NOT NULL,
	t3ver_wsid int(11) DEFAULT '0' NOT NULL,
	t3ver_label varchar(255) DEFAULT '' NOT NULL,
	t3ver_state smallint(6) DEFAULT '0' NOT NULL,
	t3ver_stage int(11) DEFAULT '0' NOT NULL,
	t3ver_count int(11) DEFAULT '0' NOT NULL,
	t3ver_tstamp int(11) DEFAULT '0' NOT NULL,
	t3ver_move_id int(11) DEFAULT '0' NOT NULL,

	sys_language_uid int(11) DEFAULT '0' NOT NULL,
	l10n_parent int(11) DEFAULT '0' NOT NULL,
	l10n_diffsource mediumblob,
	l10n_state text,

	PRIMARY KEY (uid),
	KEY parent (pid),
	KEY t3ver_oid (t3ver_oid,t3ver_wsid),
	KEY language (l10n_parent,sys_language_uid)

);

#
# Extend table structure of table 'tx_news_domain_model_news'
#
CREATE TABLE tx_news_domain_model_news (
  chh_kaplanimporter_anlass varchar(255) DEFAULT '' NULL,
  chh_kaplanimporter_zusatz varchar(255) DEFAULT '' NULL,
  chh_kaplanimporter_ort2 varchar(255) DEFAULT '' NULL,
  chh_kaplanimporter_ort varchar(255) DEFAULT '' NULL,
  chh_kaplanimporter_kategorie varchar(255) DEFAULT '' NULL
);
